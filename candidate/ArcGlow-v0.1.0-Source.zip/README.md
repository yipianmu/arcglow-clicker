# 弧光连点器

只是一款简单的连点器

![弧光连点器界面](src/Glass/readme-interface.png)

[下载 v0.1.0 Windows 便携版](https://github.com/yipianmu/arcglow-clicker/releases/download/v0.1.0/ArcGlow-v0.1.0-Portable.exe)

一个 EXE，双击就开。适用于装有 .NET Framework 4.8 的 Windows 10 和 11。

## 第一次用

1. 把小球上的准星拖到目标窗口里。鼠标连点会落在准星中心。
2. 点小球打开面板，录一个键或鼠标按键，填好间隔，点「开始这枚」。
3. 想控制另一个窗口就加一枚球。点「−」收纳，点圆环上的弧段只开那一枚，点中间展开全部。哪一枚正在输出，就亮哪一段。

| 按键 | 作用 |
| --- | --- |
| `F10` | 启动或停止全部连点 |
| `F9` | 隐藏或呼出悬浮界面 |
| `Ctrl` + `Shift` + `F10` | 紧急停止全部 |

## 换个用法，存一份就好

在设置里点「保存当前配置」给它起个名字。下次打开「切换配置」，选中那份再点「切换」。换配置时会停止已有输出。也可以导入以前保存的配置文件。

启动默认恢复退出前的布局。想从一枚新球开始，可以在设置里关掉这项。弧光强度和音效音量都能拖，界面音效默认关闭。点击声来自我的另一个项目 [哇！口袋](https://battle.yipianmu.online/)。

有些软件接收按键的方式不一样，可以先试跑几次，确认那个窗口收得到。

## 也可以加点自己的东西

设置最下面有「导出源码」。拿到 ZIP 就能改，里面有源码、构建脚本和 MIT 许可证。在 Windows PowerShell 里运行下面这行，会生成 `dist\ArcGlow.exe`。

```powershell
.\Build.ps1
```

有好用的点子也欢迎提出来。[Issues](https://github.com/yipianmu/arcglow-clicker/issues) · [MIT 许可证](LICENSE)
